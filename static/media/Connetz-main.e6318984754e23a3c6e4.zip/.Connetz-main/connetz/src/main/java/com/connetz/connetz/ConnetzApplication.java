package com.connetz.connetz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConnetzApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConnetzApplication.class, args);
    }

}
